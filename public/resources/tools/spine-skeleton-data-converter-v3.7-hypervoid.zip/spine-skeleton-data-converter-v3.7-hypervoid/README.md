# SpineSkeletonDataConverter v3.7

Packaged for Hypervoid mascot asset work.

Source: https://github.com/wang606/SpineSkeletonDataConverter
Release: v3.7

## Included

- bin/linux-x64/SpineSkeletonDataConverter: Linux x64 binary compiled locally from v3.7 source
- bin/windows-x64/SpineSkeletonDataConverter.exe: upstream Windows x64 release binary
- bin/windows-x64/SpineAtlasDowngrade.exe: upstream atlas downgrade helper
- tools/SpineConverter.py: upstream batch helper script
- tools/Spine4xTo38Converter.py: upstream 4.x-to-3.8 helper script
- licenses/SpineSkeletonDataConverter-LICENSE: upstream license

## Usage

Convert Spine binary .skel to JSON:

```bash
./bin/linux-x64/SpineSkeletonDataConverter input.skel output.json
```

Keep or target a specific complete Spine version:

```bash
./bin/linux-x64/SpineSkeletonDataConverter input.skel output.json -v 3.6.39
```

The converter auto-detects input versions and supports 3.5.x, 3.6.x, 3.7.x, 3.8.x, 4.0.x, 4.1.x, and 4.2.x.

## Verified In This Repo

The Ram mascot skeleton was converted successfully:

```bash
/tmp/ssc/SpineSkeletonDataConverter public/mascot/ram/ram.skel public/mascot/ram/ram.json
```

Detected input version: 3.6. Output JSON reports Spine 3.6.39 and is parseable by the official Spine 3.6 web runtime.
